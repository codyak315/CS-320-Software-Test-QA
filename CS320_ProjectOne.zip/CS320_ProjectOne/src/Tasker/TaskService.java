package Tasker;

import java.util.HashMap;
import java.util.Map;

public class TaskService {

	private static Map<String, Task> taskList = new HashMap<>(); // Data Structure to hold tasks
	
	// Method that adds a Task to the taskList with associated uniqueId.
	public static void addTask(String uniqueId, Task newTask) {
		newTask.setTaskId(uniqueId);
		taskList.put(uniqueId, newTask);
	}
	
	// Method that deletes a task from taskList via String param uniqueId.
	public static void deleteTask(String uniqueId) {
		taskList.remove(uniqueId);
	}
	
	// Updates the task name of a given task via String params uniqueId and taskName.
	public static void updateTaskName(String uniqueId, String taskName) {
		taskList.get(uniqueId).setTaskName(taskName);
	}
	
	// Updates the task description of a given task via String params uniqueId and description.
	public static void updateTaskDescription(String uniqueId, String description) {
		taskList.get(uniqueId).setTaskDescription(description);
	}
	
	// Getter method that takes a String param uniqueId and returns a Task object from the taskList.
	public static Task getTask(String uniqueId) {
		return taskList.get(uniqueId);
	}
}
