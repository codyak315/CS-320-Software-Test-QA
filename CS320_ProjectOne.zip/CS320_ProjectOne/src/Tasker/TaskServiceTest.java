package Tasker;

import static org.junit.Assert.*;

import org.junit.Test;

public class TaskServiceTest {

	Task testTask = new Task();
	
	@Test
	public void testAddTask() {
		String testId = "1234";
		TaskService.addTask(testId, testTask);
		
		assertTrue(TaskService.getTask(testId) == testTask);
	}

	@Test
	public void testDeleteTask() {
		String testId = "1234";
		TaskService.addTask(testId, testTask);
		TaskService.deleteTask(testId);
		
		assertTrue(TaskService.getTask(testId) == null);
	}
	
	@Test
	public void testUpdateTaskName() {
		String testId = "1234";
		String testName = "Task123";
		Task namedTask = new Task();
		
		TaskService.addTask(testId, namedTask);
		TaskService.getTask(testId).setTaskName(testName);
		
		assertTrue(TaskService.getTask(testId).getTaskName() == testName); // Verify task name
		
		String updatedTestName = "Updated";
		
		TaskService.updateTaskName(testId, updatedTestName); 
		
		assertTrue(TaskService.getTask(testId).getTaskName() == updatedTestName); // Verify name updated
	}
	
	@Test
	public void testUpdateTaskDescription() {
		String testId = "1234";
		String testDescription = "This is the original task description";
		Task describedTask = new Task();
		
		TaskService.addTask(testId, describedTask);
		TaskService.getTask(testId).setTaskDescription(testDescription);
		
		assertTrue(TaskService.getTask(testId).getTaskDescription() == testDescription); // Verify task description
		
		String updatedTestDescription = "This is the updated task description";
		
		TaskService.updateTaskDescription(testId, updatedTestDescription);
		
		assertTrue(TaskService.getTask(testId).getTaskDescription() == updatedTestDescription); // Verify description updated
	}
}
