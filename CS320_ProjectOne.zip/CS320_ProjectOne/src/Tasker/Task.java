package Tasker;

public class Task {

	// Class Variables initialized to "0".
	private String taskId = "0";
	private String taskName = "0";
	private String taskDescription = "0";
	
	// Default constructor
	public Task() {}
	
	// Constructor taking String params taskId, taskName, and description. 
	public Task(String taskId, String taskName, String description) {
		setTaskId(taskId);
		setTaskName(taskName);
		setTaskDescription(taskDescription);
	}
	
	// Sets the Task ID. If input is longer than 10 characters or null sets Task ID to "1" verifying an attempt to set has been made but was invalid.
	public void setTaskId(String taskId) {
		if(taskId.length() <= 10 && taskId != null) {
			this.taskId = taskId;
		}
		else {
			this.taskId = "1";
		}
	}
	
	// Sets the Task Name. If input is longer than 20 characters or null sets the Task Name to "1" verifying an attempt to set has been made but was invalid.
	public void setTaskName(String taskName) {
		if(taskName.length() <= 20 && taskName != null) {
			this.taskName = taskName;
		}
		else {
			this.taskName = "1";
		}
	}
	
	// Sets the Task Description. If input is longer than 50 characters or null sets the Description to "1" verifying an attempt to set has been made but was invalid.
	public void setTaskDescription(String taskDescription) {
		if(taskDescription.length() <= 50 && taskDescription != null) {
			this.taskDescription = taskDescription;
		}
		else {
			this.taskDescription = "1";
		}
	}
	
	// Getters
	public String getTaskId() {
		return this.taskId;
	}
	
	public String getTaskName() {
		return this.taskName;
	}
	
	public String getTaskDescription() {
		return this.taskDescription;
	}
	
}
