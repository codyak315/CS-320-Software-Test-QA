package Tasker;

import static org.junit.Assert.*;

import org.junit.Test;

public class TaskTest {

Task testTask = new Task();
	
	@Test
	public void testTaskId() {
		testTask.setTaskId("12345");
		
		assertTrue(testTask.getTaskId() == "12345");
	}

	@Test
	public void testTaskIdTooLong() {
		String idTooLong = "12345678999";
		testTask.setTaskId(idTooLong);
		
		assertTrue(testTask.getTaskId() == "1");
	}
	
	@Test
	public void testTaskName() {
		String taskName = "Task Name";
		testTask.setTaskId(taskName);
		
		assertTrue(testTask.getTaskId() == taskName);
	}
	
	@Test
	public void testTaskNameTooLong() {
		String nameTooLong = "This name is more than 20 characters and therefore the method should return 1";
		testTask.setTaskName(nameTooLong);
		
		assertTrue(testTask.getTaskName() == "1");
	}
	
	@Test
	public void testTaskDescription() {
		String taskDescription = "This task is to test if the method works";
		testTask.setTaskDescription(taskDescription);
		
		assertTrue(testTask.getTaskDescription() == taskDescription);
	}
	
	@Test
	public void testTaskDescriptionTooLong() {
		String tooLong = "This is a test that if the task description is longer than fifty characters that the method will not accept the description and will instead return 1";
		testTask.setTaskDescription(tooLong);
		
		assertTrue(testTask.getTaskDescription() == "1");
	}
}
