package booking;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Appointment {

	// Class variables
	private String apptId = "0";
	private String apptDescription = "0";
	private Date apptDate = new Date(0, 00, 00);
	private Date invalid = new Date(3, 00, 00); // Year = 1902
	private Date currentTime = new Date(); // Current Date
	
	// Constructor
	public Appointment() {}
	
	// Overloaded Constructor, takes String params id and description as well as a Date param date
	public Appointment(String id, Date date, String description) {
		setApptId(id);
		setApptDate(date);
		setApptDescription(description);
	}
	
	// Sets the Appointment ID variable apptId. If the ID is longer than 10 characters or is null sets apptId to "1"
	public void setApptId(String id) {
		if(id.length() <= 10 && id != null) {
			this.apptId = id;
		}
		else {
			this.apptId = "1";
			System.out.println("Invalid Appointment ID. The ID must not be empty and 10 or less characters");
		}
	}
	
	// Sets the Appointment Description variable apptDescription. If the Description is longer than 50 characters or is null sets apptDescription to "1"
	public void setApptDescription(String description) {
		if(description.length() <= 50 && description != null) {
			this.apptDescription = description;
		}
		else {
			this.apptDescription = "1";
			System.out.println("Invalid Appointment Description. The Description must not be empty and 50 or less characters.");
		}
	}
	
	// Sets the Appointment Date variable apptDate. If the given date comes before the current time or is null sets apptDate to a date with the year "1902"
	public void setApptDate(Date date) {
		if(currentTime.before(date) && date != null) {
			this.apptDate = date;
		}
		else {
			this.apptDate = invalid;
			System.out.println("Invalid Appointment Date. Cannot book appointment prior to: " + currentTime);
		}
	}
	
	
	// Getter methods
	// ---------------------------------
	public String getApptId() {
		return this.apptId;
	}
	
	public String getApptDescription() {
		return this.apptDescription;
	}
	
	public Date getApptDate() {
		return this.apptDate;
	}
	
}
