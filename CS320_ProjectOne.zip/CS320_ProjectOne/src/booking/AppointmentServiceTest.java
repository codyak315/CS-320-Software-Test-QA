package booking;

import static org.junit.Assert.*;

import org.junit.Test;

public class AppointmentServiceTest {

	private Appointment apptTest = new Appointment();
	
	@Test
	public void testAddAppt() {
		String id = "1234";
		AppointmentService.addAppt(id, apptTest);
		
		assertTrue(AppointmentService.getAppt(id) == apptTest);
	}

	@Test
	public void testDeleteAppt() {
		String id = "1234";
		AppointmentService.addAppt(id, apptTest);
		
		assertTrue(AppointmentService.getAppt(id) == apptTest); // Verify that the appointment was added to the Appointment Service
		
		AppointmentService.deleteAppt(id);
		
		assertTrue(AppointmentService.getAppt(id) == null); // Assert that the appointment added was deleted
	}
}
