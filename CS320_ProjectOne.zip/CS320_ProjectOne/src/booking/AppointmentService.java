package booking;

import java.util.HashMap;
import java.util.Map;


public class AppointmentService {

	private static Map<String, Appointment> bookingList = new HashMap<>(); // Data Structure to hold tasks
	
	// Sets the given Appointment's ID to the String id thenAdds the given appointment to bookingList with the associated String id
	public static void addAppt(String id, Appointment appt) {
		appt.setApptId(id);
		bookingList.put(id, appt);
	}
	
	// Deletes the associated Appointment from bookingList via String id
	public static void deleteAppt(String id) {
		bookingList.remove(id);
	}
	
	// Getter method that returns the given Appointment associated with the provided String id
	public static Appointment getAppt(String id) {
		return bookingList.get(id);
	}
}
