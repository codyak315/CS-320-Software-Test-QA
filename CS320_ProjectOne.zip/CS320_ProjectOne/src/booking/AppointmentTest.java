package booking;

import static org.junit.Assert.*;

import java.util.Date;
import org.junit.Test;

public class AppointmentTest {
	
	private Appointment testAppt = new Appointment();

	
	@Test
	public void testSetAppt() {
		String id = "1234";
		testAppt.setApptId(id);
		
		assertTrue(testAppt.getApptId() == id);
	}
	
	@Test
	public void testSetApptLong() {
		String id = "This ID is too long.";
		testAppt.setApptId(id);
		
		assertTrue(testAppt.getApptId() == "1"); // Assert that the ID was set to "1" as the ID is over 10 characters
	}
	
	@Test
	public void testSetDescription() {
		String description = "1234";
		testAppt.setApptDescription(description);
		
		assertTrue(testAppt.getApptDescription() == description); 
	}
	
	@Test
	public void testSetDescriptionLong() {
		String description = "This Description is too long so the method will set the apptDescription variable to '1' if this description is in fact too long.";
		testAppt.setApptDescription(description);
		
		assertTrue(testAppt.getApptDescription() == "1"); // Assert that the Description was set to "1" as the ID is over 50 characters
	}
	
	@Test
	public void testAfterDate() {
		Date testAppointment = new Date(123, 6, 27); // Set date to next year for testing purposes
		
		testAppt.setApptDate(testAppointment);
		
		assertTrue(testAppt.getApptDate().getDate() == 27); // Assert that day of month is the same as that of testAppointment since it is not in the past
	}
	
	@Test
	public void testBeforeDate() {
		Date testAppointment = new Date();
		testAppointment.setDate(25); // Sets day of month to the 25th
		testAppointment.setMonth(6); // Sets month of year to July (6+1) as months are (0-11) with 11 being December
		testAppointment.setYear(121); // Sets year to 2021 (1900 + 121)
		
		testAppt.setApptDate(testAppointment); // Attempt to set appointment date to date in the past
		
		assertTrue(testAppt.getApptDate().getYear() == 2); // Assert that since appointment date is in past, the year of the resulting appointment will be the arbitrarily set year of 1902
	}
	

}
